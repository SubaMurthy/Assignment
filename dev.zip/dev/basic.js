var ele=document.getElementsByTagName('h1');
console.log(ele);

var ele=document.getElementsByClassName('inp');
console.log(ele);

var ele=document.getElementsByClassName('inp');
console.log(ele[0].value);

var ele=document.getElementById('ad');
console.log(ele);